<?php

namespace App\Imports;

use App\Models\DPS_POI;
use Maatwebsite\Excel\Concerns\ToModel;

class ImportPOI implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new DPS_POI([
            //
            'Sort_ID' => $row[0],
            'DPS_ID' => $row[1],
            'Source_ID' => $row[2],
            'Source' => $row[3],
            'UID' => $row[4],
            'POI_N_Eng' => $row[5],
            'POI_N_Myn3' => $row[6],
            'Type' => $row[7],
            'Type_Code' => $row[8],
            'Sub_Type' => $row[9],
            'Sub_Type_Code' => $row[10],
            'Postal_Code' => $row[11],
            'St_N_Eng' => $row[12],
            'St_N_Myn3' => $row[13],
            'Ward_N_Eng' => $row[14],
            'Ward_N_Myn3' => $row[15],
            'Tsp_N_Eng' => $row[16],
            'Tsp_N_Myn3' => $row[17],
            'Dist_N_Eng' => $row[18],
            'Dist_N_Myn3' => $row[19],
            'S_R_N_Eng' => $row[20],
            'S_R_N_Myn3' => $row[21],
            'HN_Eng' => $row[22],
            'HN_Myn3' => $row[23],
            'Longitude' => $row[24],
            'Lattitude' => $row[25],
            'Remark' => $row[26],
            'Verify_Date' => $row[27],
        ]);
    }
}
