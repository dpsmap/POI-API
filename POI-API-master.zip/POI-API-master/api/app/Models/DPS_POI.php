<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DPS_POI extends Model
{
    use HasFactory;
    protected $fillable = [
            'Sort_ID',
            'DPS_ID',
            'Source_ID',
            'Source',
            'UID',
            'POI_N_Eng',
            'POI_N_Myn3',
            'Type',
            'Type_Code',
            'Sub_Type',
            'Sub_Type_Code',
            'Postal_Code',
            'St_N_Eng',
            'St_N_Myn3',
            'Ward_N_Eng',
            'Ward_N_Myn3',
            'Tsp_N_Eng',
            'Tsp_N_Myn3',
            'Dist_N_Eng',
            'Dist_N_Myn3',
            'S_R_N_Eng',
            'S_R_N_Myn3',
            'HN_Eng',
            'HN_Myn3',
            'Longitude',
            'Lattitude',
            'Remark',
            'Verify_Date',
    ];
}
