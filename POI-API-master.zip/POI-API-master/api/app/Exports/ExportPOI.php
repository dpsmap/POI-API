<?php

namespace App\Exports;

use App\Models\DPS_POI;
use Maatwebsite\Excel\Concerns\FromCollection;

class ExportPOI implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return DPS_POI::all();
    }
}
