<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ImportPOI;
use App\Exports\ExportPOI;
use App\Models\DPS_POI;
use Illuminate\Support\Facades\DB;
class DashboardController extends Controller
{
    //
    public function index()
    {
        $data = DB::table('d_p_s__p_o_i_s')->paginate(15);
        return view('dashboard/dashboard',[
            'data' => $data
        ]);
    }
    public function register()
    {
        return view('dashboard/register');
    }
    public function manual(){
        return view('dashboard/manual');
    }
    public function configuration()
    {
        return view('dashboard/configuration');
    }
    public function poi()
    {
        return view('dashboard/poi');
    }
    public function importPOI(Request $request){
        $request->validate([
            'file' => 'required',
        ]);
        Excel::import(new ImportPOI,
                      $request->file('file')->store('files'));
        return redirect()->back()->with('success', 'Excel Imported Success');
    }
    public function exportPOI(Request $request){
        return Excel::download(new ExportPOI, 'poi.xlsx');
    }
}
