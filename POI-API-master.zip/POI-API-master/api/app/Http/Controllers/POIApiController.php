<?php

namespace App\Http\Controllers;

use App\Models\DPS_POI;
use Illuminate\Http\Request;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

class POIApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return DPS_POI::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $poi = new DPS_POI;

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DPS_POI  $dPS_POI
     * @return \Illuminate\Http\Response
     */
    //public function show(DPS_POI $dPS_POI)
    public function show($id)
    {
        //
        return DPS_POI::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DPS_POI  $dPS_POI
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DPS_POI $dPS_POI)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DPS_POI  $dPS_POI
     * @return \Illuminate\Http\Response
     */
    public function destroy(DPS_POI $dPS_POI)
    {
        //
    }
}
