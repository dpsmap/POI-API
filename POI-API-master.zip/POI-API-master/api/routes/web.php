<?php

use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\POIController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    dd(php_ini_loaded_file());
    //return view('auth/login');
});

//dashboard
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/dashboard/register', [DashboardController::class, 'register'])->name('dashboard.register');
Route::get('/dashboard/poi', [DashboardController::class, 'poi'])->name('dashboard.poi');
Route::get('/dashboard/manual', [DashboardController::class, 'manual'])->name('dashboard.manual');
Route::post('/dashboard/poi', [DashboardController::class, 'importPOI'])->name('dashboard.poi.import');
Route::get('/dashboard/poi/export', [DashboardController::class, 'exportPOI'])->name('dashboard.poi.export');
Route::get('/dashboard/configuration', [DashboardController::class, 'configuration'])->name('dashboard');


Route::get('/file-import', [
    POIController::class,
    'importView'
])->name('import-view');
Route::post('/import', [
    POIController::class,
    'import'
])->name('import');

Route::get('/export-users', [
    POIController::class,
    'exportUsers'
])->name('export-users');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
