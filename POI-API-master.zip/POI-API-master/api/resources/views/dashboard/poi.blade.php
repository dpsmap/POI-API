@extends('layouts.app')

@section('content')
    <div class='container-fluid'>
        <div class='row'>
            <div class='col-lg-3 dashboard-left'>
                <div class='dashboard-head'>
                    <h3 class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard"><u>Dashboard</u></a></h3>
                    <hr class="white">
                </div>
                <div>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/manual"> Manual
                        </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/register"> Register Admin
                            User
                        </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/poi"> Upload Excel File
                        </a></p>

                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/configuration">
                            Configuration
                        </a></p>
                    <hr class="white">
                    <figure>
                        <figcaption class="blockquote-footer white">
                            Developed By <cite title="Source Title">MT Tech</cite>
                        </figcaption>
                    </figure>
                </div>
            </div>

            <div class='col-lg-9'>
                <div class="container">
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
                    <div class="card bg-light mt-3">
                        <div class="card-header">
                            Import and Export Excel data
                            to POI database
                        </div>
                        <div class="card-body">
                            <form action="{{ route('dashboard.poi.import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <input type="file" name="file" class="form-control @error('file') is-invalid @enderror">
                                @error('file')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                <br>
                                <button class="btn btn-success">
                                    Import POI Data
                                </button>
                                <a class="btn btn-warning" href="{{ route('dashboard.poi.export') }}">
                                    Export POI Data
                                </a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endsection
