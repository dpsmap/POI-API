@extends('layouts.app')

@section('content')
    <div class='container-fluid'>
        <div class='row'>
            <div class='col-lg-3 dashboard-left'>
                <div class='dashboard-head'>
                    <h3 class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard"><u>Dashboard</u></a></h3>
                    <hr class="white">
                </div>
                <div>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/manual"> Manual
                    </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/register"> Register Admin User
                        </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/poi"> Upload Excel File
                        </a></p>

                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/configuration"> Configuration
                        </a></p>
                    <hr class="white">
                    <figure>
                        <figcaption class="blockquote-footer white">
                            Developed By <cite title="Source Title">MT Tech</cite>
                        </figcaption>
                    </figure>
                </div>
            </div>

            <div class='col-lg-9'></div>
        </div>
    @endsection
