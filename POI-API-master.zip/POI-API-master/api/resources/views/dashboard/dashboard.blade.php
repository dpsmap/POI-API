@extends('layouts.app')

@section('content')
    <div class='container-fluid'>
        <div class='row'>
            <div class='col-lg-3 dashboard-left'>
                <div class='dashboard-head'>
                    <h3 class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard"><u>Dashboard</u></a></h3>
                    <hr class="white">
                </div>
                <div>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/manual"> Manual
                        </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/register"> Register Admin
                            User
                        </a></p>
                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/poi"> Upload Excel File
                        </a></p>

                    <p class="white"><a class="a-dashboard" href="{{ URL::to('/') }}/dashboard/configuration">
                            Configuration
                        </a></p>
                    <hr class="white">
                    <figure>
                        <figcaption class="blockquote-footer white">
                            Developed By <cite title="Source Title">MT Tech</cite>
                        </figcaption>
                    </figure>
                </div>
            </div>

            <div class='col-lg-9'>
                <table class="table table-bordered">
                    {!! $data->links() !!}
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Sort_ID</th>
                            <th scope="col">DPS_ID</th>
                            <th scope="col">Source_ID</th>
                            <th scope="col">Source</th>
                            <th scope="col">UID</th>
                            <th scope="col">POI_N_Eng</th>
                            <th scope="col">POI_N_Myn3</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $poi)
                        <tr>
                            <td scope="col">{{ $poi->Sort_ID }}</td>
                            <td scope="col">{{ $poi->DPS_ID }}</td>
                            <td scope="col">{{ $poi->Source_ID }}</td>
                            <td scope="col">{{ $poi->Source }}</td>
                            <td scope="col">{{ $poi->UID }}</td>
                            <td scope="col">{{ $poi->POI_N_Eng }}</td>
                            <td scope="col">{{ $poi->POI_N_Myn3 }}</td>
                        </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    @endsection
