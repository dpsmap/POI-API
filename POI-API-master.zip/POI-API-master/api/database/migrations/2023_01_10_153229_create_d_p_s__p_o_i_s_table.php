<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_p_s__p_o_i_s', function (Blueprint $table) {
            $table->id();
            $table->string('Sort_ID');
            $table->string('DPS_ID')->nullable();
            $table->string('Source_ID')->nullable();
            $table->string('Source')->nullable();
            $table->string('UID')->nullable();
            $table->string('POI_N_Eng')->nullable();
            $table->string('POI_N_Myn3')->nullable();
            $table->string('Type')->nullable();
            $table->string('Type_Code')->nullable();
            $table->string('Sub_Type')->nullable();
            $table->string('Sub_Type_Code')->nullable();
            $table->string('Postal_Code')->nullable();
            $table->string('St_N_Eng')->nullable();
            $table->string('St_N_Myn3')->nullable();
            $table->string('Ward_N_Eng')->nullable();
            $table->string('Ward_N_Myn3')->nullable();
            $table->string('Tsp_N_Eng')->nullable();
            $table->string('Tsp_N_Myn3')->nullable();
            $table->string('Dist_N_Eng')->nullable();
            $table->string('Dist_N_Myn3')->nullable();
            $table->string('S_R_N_Eng')->nullable();
            $table->string('S_R_N_Myn3')->nullable();
            $table->string('HN_Eng')->nullable();
            $table->string('HN_Myn3')->nullable();
            $table->string('Longitude')->nullable();
            $table->string('Lattitude')->nullable();
            $table->string('Remark')->nullable();
            $table->string('Verify_Date')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_p_s__p_o_i_s');
    }
};
